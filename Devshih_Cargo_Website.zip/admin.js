const KEY="devshih_cargo_shipments";
const DEMO=[
{id:1,phone:"99112233",name:"Бат",item:"Гутал (Nike)",category:"Гутал",weight:1.5,price:12000,status:"Монголд ирсэн",date:"2026-09-12"},
{id:2,phone:"99112233",name:"Бат",item:"Цүнх",category:"Цүнх",weight:2.3,price:18400,status:"Замд явж байна",date:"2026-09-10"},
{id:3,phone:"99112233",name:"Бат",item:"Чихэвч (AirPods)",category:"Электроник",weight:.8,price:8000,status:"Гарал үүссэн",date:"2026-09-08"},
{id:4,phone:"88001122",name:"Сараа",item:"Хүрэм",category:"Хувцас",weight:1.8,price:14500,status:"Хүлээн авахад бэлэн",date:"2026-09-14"}];

function data(){try{return JSON.parse(localStorage.getItem(KEY))||DEMO}catch{return DEMO}}
function save(x){localStorage.setItem(KEY,JSON.stringify(x));render()}
function money(n){return Number(n).toLocaleString("mn-MN")+"₮"}
function render(){
 const list=data(), box=document.querySelector("#adminList");
 document.querySelector("#adminCount").textContent=`Нийт ${list.length} бүртгэл`;
 box.innerHTML="";
 list.forEach(s=>{
  const row=document.createElement("div");row.className="admin-row";
  row.innerHTML=`
   <div><b>${s.name}</b><br><small>${s.phone}</small></div>
   <div><b>${s.item}</b><br><small>${s.category||"—"} · ${s.weight} кг</small></div>
   <div><b>${money(s.price)}</b></div>
   <div><small>${s.status}</small></div>
   <div><small>${s.date||"—"}</small></div>
   <div class="row-actions">
    <button class="ghost-btn" onclick="editShipment(${s.id})">Засах</button>
    <button class="danger-btn" onclick="deleteShipment(${s.id})">Устгах</button>
   </div>`;
  box.appendChild(row);
 })
}
window.deleteShipment=id=>{if(confirm("Энэ илгээмжийг устгах уу?"))save(data().filter(x=>x.id!==id))}
window.editShipment=id=>{
 const s=data().find(x=>x.id===id); if(!s)return;
 document.querySelector("#sPhone").value=s.phone;document.querySelector("#sName").value=s.name;
 document.querySelector("#sItem").value=s.item;document.querySelector("#sCategory").value=s.category||"";
 document.querySelector("#sWeight").value=s.weight;document.querySelector("#sPrice").value=s.price;
 document.querySelector("#sStatus").value=s.status;document.querySelector("#sDate").value=s.date||"";
 document.querySelector("#shipmentForm").dataset.edit=id;
 window.scrollTo({top:0,behavior:"smooth"});
}

document.querySelector("#loginForm").addEventListener("submit",e=>{
 e.preventDefault();
 if(document.querySelector("#adminPassword").value==="1234"){
  sessionStorage.setItem("devshih_admin","1");showAdmin();
 }else alert("Нууц үг буруу байна.");
});
function showAdmin(){
 document.querySelector("#loginPanel").classList.add("hidden");
 document.querySelector("#adminPanel").classList.remove("hidden");
 render();
}
if(sessionStorage.getItem("devshih_admin")==="1")showAdmin();
document.querySelector("#logoutBtn").addEventListener("click",()=>{sessionStorage.removeItem("devshih_admin");location.reload()});
document.querySelector("#resetDemo").addEventListener("click",()=>{if(confirm("Бүх мэдээллийг демо мэдээллээр солих уу?")){localStorage.setItem(KEY,JSON.stringify(DEMO));render()}});

document.querySelector("#shipmentForm").addEventListener("submit",e=>{
 e.preventDefault();
 const f=id=>document.querySelector(id).value;
 const phone=f("#sPhone").replace(/\D/g,"");
 if(phone.length!==8){alert("8 оронтой утасны дугаар оруулна уу.");return}
 const list=data(), editId=e.currentTarget.dataset.edit;
 const item={id:editId?Number(editId):Date.now(),phone,name:f("#sName"),item:f("#sItem"),category:f("#sCategory"),weight:Number(f("#sWeight")),price:Number(f("#sPrice")),status:f("#sStatus"),date:f("#sDate")||new Date().toISOString().slice(0,10)};
 const next=editId?list.map(x=>x.id===Number(editId)?item:x):[item,...list];
 save(next);e.currentTarget.reset();delete e.currentTarget.dataset.edit;alert(editId?"Шинэчлэгдлээ.":"Илгээмж нэмэгдлээ.");
});
