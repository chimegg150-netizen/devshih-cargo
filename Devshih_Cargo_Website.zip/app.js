const KEY = "devshih_cargo_shipments";

const demo = [
  {id:1,phone:"99112233",name:"Бат",item:"Гутал (Nike)",category:"Гутал",weight:1.5,price:12000,status:"Монголд ирсэн",date:"2026-09-12"},
  {id:2,phone:"99112233",name:"Бат",item:"Цүнх",category:"Цүнх",weight:2.3,price:18400,status:"Замд явж байна",date:"2026-09-10"},
  {id:3,phone:"99112233",name:"Бат",item:"Чихэвч (AirPods)",category:"Электроник",weight:.8,price:8000,status:"Гарал үүссэн",date:"2026-09-08"},
  {id:4,phone:"88001122",name:"Сараа",item:"Хүрэм",category:"Хувцас",weight:1.8,price:14500,status:"Хүлээн авахад бэлэн",date:"2026-09-14"}
];

function getData(){
  const raw=localStorage.getItem(KEY);
  if(!raw){localStorage.setItem(KEY,JSON.stringify(demo));return demo}
  try{return JSON.parse(raw)}catch{return demo}
}
function money(n){return Number(n).toLocaleString("mn-MN")+"₮"}
function statusClass(s){
  if(s.includes("бэлэн")) return "ready";
  if(s.includes("Хүргэгдсэн")) return "done";
  if(s.includes("Замд")) return "transit";
  return "wait";
}
function render(list,phone){
  const results=document.querySelector("#results"), box=document.querySelector("#shipmentList");
  results.classList.remove("hidden");
  document.querySelector("#resultTitle").textContent=`${phone} дугаартай хэрэглэгчийн илгээмж`;
  document.querySelector("#resultCount").textContent=`Нийт ${list.length} илгээмж`;
  box.innerHTML="";
  if(!list.length){
    box.innerHTML=`<div class="panel"><h3>Илгээмж олдсонгүй.</h3><p class="meta">Утасны дугаараа шалгаад дахин оролдоно уу.</p></div>`;
    return;
  }
  list.forEach(s=>{
    const el=document.createElement("article"); el.className="shipment";
    el.innerHTML=`
      <div><h3>📦 ${s.item}</h3><div class="meta">👤 ${s.name} · ${s.phone}<br>⚖️ ${s.weight} кг · ${s.category||"Бараа"} · 📅 ${s.date||"—"}</div></div>
      <div><span class="status ${statusClass(s.status)}">● ${s.status}</span></div>
      <div><div class="meta">Төлбөр</div><div class="price">${money(s.price)}</div></div>
      <div class="action"><button onclick="alert('Илгээмж: ${String(s.item).replaceAll("'","\\'")}\\nУтас: ${s.phone}\\nТөлөв: ${s.status}\\nЖин: ${s.weight} кг\\nҮнэ: ${money(s.price)}')">Дэлгэрэнгүй →</button></div>`;
    box.appendChild(el);
  });
}
document.querySelector("#trackForm").addEventListener("submit",e=>{
  e.preventDefault();
  const phone=document.querySelector("#phone").value.replace(/\D/g,"");
  if(phone.length!==8){alert("8 оронтой утасны дугаар оруулна уу.");return}
  const list=getData().filter(x=>x.phone===phone);
  render(list,phone);
  document.querySelector("#results").scrollIntoView({behavior:"smooth"});
});
